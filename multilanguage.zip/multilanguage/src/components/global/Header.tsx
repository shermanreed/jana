import React from "react";
import ChangeLang from "./ChangeLang";
export default function Header() {
  return (
    <div className="w-full h-20 p-2 bg-black flex items-center">
      <ChangeLang />
    </div>
  );
}
