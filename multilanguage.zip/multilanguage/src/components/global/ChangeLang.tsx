"use client";
import React from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import Cookies from "js-cookie";

export default function ChangeLang() {
  const t = useTranslations("HomePage");
  const router = useRouter();

  const changeLanguage = (locale: string) => {
    Cookies.set("NEXT_LOCALE", locale);
    router.refresh();
  };
  return (
    <button
      className="bg-blue-100 p-2 rounded-md hover:bg-blue-200"
      onClick={() => {
        changeLanguage(Cookies.get("NEXT_LOCALE") === "fa" ? "en" : "fa");
      }}
    >
      {t("change-lang")}
    </button>
  );
}
